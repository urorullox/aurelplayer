import React, { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  Repeat,
  Shuffle,
  SkipBack,
  SkipForward,
  Volume2,
  Heart
} from "lucide-react";

const albums = [
  {
    title: "Hivi!",
    cover: "/albums/hivi.jpg",
    songs: ["Pelangi", "Remaja", "Siapkah Kau Tuk Jatuh Cinta Lagi"],
    color: "from-purple-600 to-pink-600"
  },
  {
    title: "Jennie",
    cover: "/albums/jennie.jpg",
    songs: ["You & Me", "Solo"],
    color: "from-pink-500 to-rose-500"
  },
  {
    title: "Ariana Grande",
    cover: "/albums/ariana.jpg",
    songs: ["Into You", "Positions", "No Tears Left To Cry"],
    color: "from-violet-500 to-purple-600"
  },
  {
    title: "Banda Neira",
    cover: "/albums/banda.jpg",
    songs: ["Sampai Jadi Debu", "Yang Patah Tumbuh"],
    color: "from-indigo-500 to-purple-500"
  },
  {
    title: "Nadin Amizah",
    cover: "/albums/nadin.jpg",
    songs: ["Bertaut", "Amin Paling Serius"],
    color: "from-pink-400 to-rose-400"
  },
  {
    title: "For You",
    cover: "/albums/foryou.jpg",
    songs: [
      "Nothing - Bruno Major",
      "The Most Beautiful Thing",
      "Best Part",
      "Favorite Girl",
      "Sanctuary",
      "Mine - Petra Sihombing",
      "One Call Away",
      "Waiting Room",
      "I'm Yours",
      "Out of My League",
      "The Only Exception"
    ],
    color: "from-rose-500 to-pink-500"
  }
];

export default function MusicPlayer() {
  const [selectedAlbum, setSelectedAlbum] = useState(null);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isLoop, setIsLoop] = useState(false);
  const [nowPlaying, setNowPlaying] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [message, setMessage] = useState("");
  const [progress, setProgress] = useState(45);
  const [volume, setVolume] = useState(75);
  const [liked, setLiked] = useState(new Set());
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [isSliding, setIsSliding] = useState(false);
  const [currentTime, setCurrentTime] = useState("1:23");
  const [totalTime, setTotalTime] = useState("3:47");
  const audioRef = useRef(null);

  const nextSong = () => {
    if (!selectedAlbum && isShuffle) {
      const random = Math.floor(Math.random() * allSongs.length);
      const { album, song } = allSongs[random];
      playSong(album, album.songs.indexOf(song));
      return;
    }
    
      const currentAlbumIndex = albums.findIndex((a) => a.title === selectedAlbum.title);
      const nextAlbum = albums[(currentAlbumIndex + 1) % albums.length];
      playSong(nextAlbum, 0);
      return;
    }
    playSong(selectedAlbum, nextIndex);
  };

  const prevSong = () => {
    if (!selectedAlbum) return;
    const songs = selectedAlbum.songs;
    const prevIndex = currentIndex === 0 ? songs.length - 1 : currentIndex - 1;
    playSong(selectedAlbum, prevIndex);
  };

useEffect(() => {
  if (audioRef.current) {
    audioRef.current.volume = volume / 100;
  }
}, [volume]);

useEffect(() => {
  if (audioRef.current) {
    if (isPlaying) {
      audioRef.current.play().catch(console.error);
    } else {
      audioRef.current.pause();
    }
  }
}, [isPlaying, nowPlaying]);

useEffect(() => {
  const audio = audioRef.current;
  if (!audio) return;

  const handleTimeUpdate = () => {
    const percent = (audio.currentTime / audio.duration) * 100;
    setProgress(percent);
    setCurrentTime(formatTime(Math.floor(audio.currentTime)));
    setTotalTime(formatTime(Math.floor(audio.duration)));
  };

  const handleEnded = () => {
    if (isLoop) {
      audio.currentTime = 0;
      audio.play();
    } else {
      nextSong();
    }
  };

  audio.addEventListener("timeupdate", handleTimeUpdate);
  audio.addEventListener("ended", handleEnded);

  return () => {
    audio.removeEventListener("timeupdate", handleTimeUpdate);
    audio.removeEventListener("ended", handleEnded);
  };
}, [isLoop, nextSong]);

  const allSongs = albums.flatMap((album) =>
    album.songs.map((song) => ({ song, album }))
  );

  // Auto-increment progress simulation
  useEffect(() => {
    let interval;
    if (isPlaying && !isSliding) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            nextSong();
            return 0;
          }
          return prev + 0.5;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, isSliding]);

  const showMessage = (text) => {
    setMessage(text);
    setTimeout(() => setMessage(""), 2500);
  };

  const playSong = (album, index) => {
    setSelectedAlbum(album);
    setCurrentIndex(index);
    setNowPlaying(album.songs[index]);
    setIsPlaying(true);
    setProgress(0);
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleShuffle = (global = false) => {
    setIsShuffle((prev) => {
      if (!prev) {
        setIsLoop(false);
        if (global) {
          const random = Math.floor(Math.random() * allSongs.length);
          const { album, song } = allSongs[random];
          playSong(album, album.songs.indexOf(song)); // ✅ pakai playSong
          showMessage("✨ Shuffling all for you baby girl");
        }        
        } else if (selectedAlbum) {
          const random = Math.floor(Math.random() * selectedAlbum.songs.length);
          playSong(selectedAlbum, random);
          showMessage(`🔀 Shuffling ${selectedAlbum.title} album`);
        }
        return true;
      } else {
        showMessage("🔀 Turn off shuffling");
        return false;
      }
    });
  };

  const toggleLoop = () => {
    setIsLoop((prev) => {
      if (!prev) {
        setIsShuffle(false);
        if (nowPlaying) showMessage(`🔁 Looping ${nowPlaying}`);
        return true;
      } else {
        showMessage("🔁 Turn off looping");
        return false;
      }
    });
  };
  
  const toggleLike = (song) => {
    setLiked(prev => {
      const newLiked = new Set(prev);
      if (newLiked.has(song)) {
        newLiked.delete(song);
        showMessage("💔 Removed from favorites");
      } else {
        newLiked.add(song);
        showMessage("💖 Added to favorites");
      }
      return newLiked;
    });
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressChange = (e) => {
    const newProgress = e.target.value;
    setProgress(newProgress);
  
    if (audioRef.current) {
      const duration = audioRef.current.duration;
      const newTime = (newProgress / 100) * duration;
      audioRef.current.currentTime = newTime;
    }
  };
  
  const handleSlideStart = () => {
    setIsSliding(true);
  };

  const handleSlideEnd = () => {
    setIsSliding(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-pink-900 to-purple-900 text-white pb-32 font-sans relative overflow-hidden">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-pink-400 rounded-full opacity-20 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      {/* Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5 select-none">
        <div className="text-center transform -rotate-12">
          <div className="text-8xl md:text-9xl font-serif italic text-pink-300 mb-2" style={{fontFamily: 'Brush Script MT, cursive'}}>
            Aurel
          </div>
          <div className="text-2xl text-pink-400 font-light tracking-widest">
            by jess.edit
          </div>
        </div>
      </div>

      <div className="relative z-10 p-4">
        {/* Profile Section with enhanced animations */}
        <div className="flex items-center gap-4 mb-6 group">
          <div className="relative">
            <img
              src="/profile.jpg"
              alt="Profile"
              className="w-16 h-16 rounded-full shadow-lg border-3 border-pink-300 transition-all duration-300 group-hover:scale-110 group-hover:shadow-pink-500/50"
            />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white animate-pulse"></div>
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white mb-1 transition-all duration-300 group-hover:text-pink-300">
              Aurel Kyhand Diva Ramadani
            </h1>
            <p className="text-sm text-pink-200 opacity-80">By Jess</p>
          </div>
        </div>

        {/* Control buttons with enhanced animations */}
        {!selectedAlbum && (
          <div className="flex gap-4 mb-8 justify-center">
            <button
              onClick={() => toggleShuffle(true)}
              className={`group relative rounded-full p-4 transition-all duration-300 transform hover:scale-110 active:scale-95 ${
                isShuffle 
                  ? "bg-gradient-to-r from-pink-500 to-rose-500 shadow-lg shadow-pink-500/50" 
                  : "bg-white/10 hover:bg-white/20"
              } text-white backdrop-blur-sm`}
            >
              <Shuffle className="transition-transform duration-300 group-hover:rotate-12" />
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-pink-400 to-rose-400 opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
            </button>
            <button
              onClick={toggleLoop}
              className={`group relative rounded-full p-4 transition-all duration-300 transform hover:scale-110 active:scale-95 ${
                isLoop 
                  ? "bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-500/50" 
                  : "bg-white/10 hover:bg-white/20"
              } text-white backdrop-blur-sm`}
            >
              <Repeat className="transition-transform duration-300 group-hover:rotate-180" />
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
            </button>
            <button
              onClick={nowPlaying ? togglePlayPause : () => playSong(albums[0], 0)}
              className="group relative rounded-full p-4 bg-gradient-to-r from-pink-500 to-rose-500 text-white transition-all duration-300 transform hover:scale-110 active:scale-95 shadow-lg shadow-pink-500/50 backdrop-blur-sm"
            >
              {nowPlaying && isPlaying ? 
                <Pause className="transition-all duration-300 group-hover:scale-110" /> : 
                <Play className="transition-all duration-300 group-hover:scale-110 group-hover:translate-x-0.5" />
              }
              <div className="absolute inset-0 rounded-full bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
            </button>
          </div>
        )}

        {/* Album grid or song list with enhanced animations */}
        <div className="transition-all duration-500 ease-in-out">
          {!selectedAlbum ? (
            <div className="grid grid-cols-2 gap-4">
              {albums.map((album, idx) => (
                <div
                  key={idx}
                  className="group relative bg-white/5 backdrop-blur-sm rounded-2xl p-4 flex flex-col items-center hover:bg-white/10 cursor-pointer transition-all duration-300 transform hover:scale-105 hover:-translate-y-2 active:scale-95 border border-white/10 hover:border-pink-400/50"
                  onClick={() => setSelectedAlbum(album)}
                  style={{
                    animationDelay: `${idx * 100}ms`
                  }}
                >
                  <div className="relative mb-3 group-hover:scale-110 transition-transform duration-300">
                    <img
                      src={album.cover}
                      alt={album.title}
                      className="w-28 h-28 rounded-xl shadow-lg object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <Play className="text-white w-8 h-8 drop-shadow-lg" />
                    </div>
                  </div>
                  <h2 className="text-sm font-semibold text-center group-hover:text-pink-300 transition-colors duration-300">{album.title}</h2>
                  <p className="text-xs text-pink-200 opacity-60 mt-1">{album.songs.length} songs</p>
                  
                  {/* Floating gradient background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${album.color} rounded-2xl opacity-0 group-hover:opacity-10 transition-opacity duration-300 -z-10`}></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="animate-slide-in">
              <button
                className="mb-6 text-sm text-pink-300 hover:text-white transition-colors duration-300 flex items-center gap-2 group"
                onClick={() => setSelectedAlbum(null)}
              >
                <span className="transition-transform duration-300 group-hover:-translate-x-1">←</span>
                Kembali ke daftar album
              </button>
              
              {/* Album header with enhanced styling */}
              <div className="flex items-center gap-6 mb-6 p-4 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10">
                <div className="relative group">
                  <img
                    src={selectedAlbum.cover}
                    alt={selectedAlbum.title}
                    className="w-24 h-24 rounded-xl shadow-lg transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-br ${selectedAlbum.color} rounded-xl opacity-20 group-hover:opacity-30 transition-opacity duration-300`}></div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold mb-2">{selectedAlbum.title}</h2>
                  <p className="text-sm text-pink-200 opacity-80">
                    {selectedAlbum.songs.length} Lagu • {Math.floor(selectedAlbum.songs.length * 3.5)} min
                  </p>
                </div>
              </div>

              {/* Control buttons for album */}
              <div className="flex gap-4 mb-6 justify-center">
                <button
                  onClick={() => toggleShuffle(false)}
                  className={`group relative rounded-full p-3 transition-all duration-300 transform hover:scale-110 active:scale-95 ${
                    isShuffle 
                      ? "bg-gradient-to-r from-pink-500 to-rose-500 shadow-lg shadow-pink-500/50" 
                      : "bg-white/10 hover:bg-white/20"
                  } text-white backdrop-blur-sm`}
                >
                  <Shuffle size={20} className="transition-transform duration-300 group-hover:rotate-12" />
                </button>
                <button
                  onClick={toggleLoop}
                  className={`group relative rounded-full p-3 transition-all duration-300 transform hover:scale-110 active:scale-95 ${
                    isLoop 
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-500/50" 
                      : "bg-white/10 hover:bg-white/20"
                  } text-white backdrop-blur-sm`}
                >
                  <Repeat size={20} className="transition-transform duration-300 group-hover:rotate-180" />
                </button>
                <button
                  onClick={nowPlaying ? togglePlayPause : () => playSong(selectedAlbum, 0)}
                  className="group relative rounded-full p-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white transition-all duration-300 transform hover:scale-110 active:scale-95 shadow-lg shadow-pink-500/50 backdrop-blur-sm"
                >
                  {nowPlaying && isPlaying ? 
                    <Pause size={20} className="transition-all duration-300 group-hover:scale-110" /> : 
                    <Play size={20} className="transition-all duration-300 group-hover:scale-110 group-hover:translate-x-0.5" />
                  }
                </button>
              </div>

              {/* Song list with enhanced animations */}
              <div className="space-y-3">
                {selectedAlbum.songs.map((song, i) => (
                  <div
                    key={i}
                    className={`group relative bg-white/5 backdrop-blur-sm rounded-xl p-4 flex items-center justify-between hover:bg-white/10 transition-all duration-300 transform hover:scale-102 active:scale-98 border border-white/5 hover:border-pink-400/30 cursor-pointer ${
                      nowPlaying === song ? "bg-gradient-to-r from-pink-600/20 to-rose-600/20 border-pink-400/50" : ""
                    }`}
                    style={{
                      animationDelay: `${i * 50}ms`
                    }}
                    onClick={() => playSong(selectedAlbum, i)}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="text-pink-300 font-mono text-sm opacity-60 w-6">
                        {String(i + 1).padStart(2, '0')}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-white group-hover:text-pink-300 transition-colors duration-300">
                          {song}
                        </p>
                        <p className="text-xs text-pink-200 opacity-60 mt-1">
                          {selectedAlbum.title}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLike(song);
                        }}
                        className={`p-2 rounded-full transition-all duration-300 hover:scale-110 ${
                          liked.has(song) ? "text-pink-500" : "text-gray-400 hover:text-pink-400"
                        }`}
                      >
                        <Heart size={16} className={liked.has(song) ? "fill-current" : ""} />
                      </button>
                    </div>
                    
                    {/* Animated background for current song */}
                    {nowPlaying === song && (
                      <div className="absolute left-0 top-0 h-full bg-gradient-to-r from-pink-500/20 to-transparent rounded-xl animate-pulse"></div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Enhanced message notification */}
      {message && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-pink-900/90 to-rose-900/90 backdrop-blur-lg px-6 py-3 rounded-full text-sm text-white shadow-lg z-50 border border-pink-400/30 animate-bounce-in">
          {message}
        </div>
      )}

      {/* Enhanced bottom player */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-black via-pink-950/80 to-pink-900/60 backdrop-blur-xl border-t border-pink-800/50 shadow-2xl px-4 py-4 z-40">
        {nowPlaying && (
          <div className="space-y-4">
            {/* Now playing info */}
            <div className="text-center">
              <p className="text-sm font-semibold text-pink-200 mb-1">Now Playing</p>
              <p className="text-xs text-pink-300 flex items-center justify-center gap-3">
                <span className="truncate max-w-48">{nowPlaying}</span>
                <div className="flex gap-2">
                  {isLoop && <Repeat size={12} className="text-purple-400 animate-pulse" />}
                  {isShuffle && <Shuffle size={12} className="text-pink-400 animate-pulse" />}
                  {liked.has(nowPlaying) && <Heart size={12} className="text-pink-500 fill-current animate-pulse" />}
                </div>
              </p>
            </div>

            {/* Progress bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-pink-300">
                <span>{currentTime}</span>
                <span>{totalTime}</span>
              </div>
              <div className="relative group">
                <input
                  type="range"
                  className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer slider"
                  min="0"
                  max="100"
                  value={progress}
                  onChange={handleProgressChange}
                  onMouseDown={handleSlideStart}
                  onMouseUp={handleSlideEnd}
                  onTouchStart={handleSlideStart}
                  onTouchEnd={handleSlideEnd}
                />
                <div 
                  className="absolute top-0 left-0 h-2 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full pointer-events-none transition-all duration-300"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleLike(nowPlaying)}
                  className={`p-2 rounded-full transition-all duration-300 hover:scale-110 ${
                    liked.has(nowPlaying) ? "text-pink-500" : "text-gray-400 hover:text-pink-400"
                  }`}
                >
                  <Heart size={18} className={liked.has(nowPlaying) ? "fill-current" : ""} />
                </button>
                <div className="relative">
                  <button
                    onClick={() => setShowVolumeSlider(!showVolumeSlider)}
                    className="text-pink-300 hover:text-white transition-colors duration-300 p-2 rounded-full hover:bg-white/10"
                  >
                    <Volume2 size={18} />
                  </button>
                  {showVolumeSlider && (
                    <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 bg-black/80 backdrop-blur-sm rounded-lg p-3 w-32">
                      <input
                        type="range"
                        className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer volume-slider"
                        min="0"
                        max="100"
                        value={volume}
                        onChange={(e) => setVolume(e.target.value)}
                      />
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4">
                <button 
                  onClick={prevSong} 
                  className="text-pink-300 hover:text-white transition-all duration-300 hover:scale-110 active:scale-95 p-2 rounded-full hover:bg-white/10"
                >
                  <SkipBack size={20} />
                </button>
                <button
                  onClick={togglePlayPause}
                  className="bg-gradient-to-r from-pink-500 to-rose-500 text-white p-3 rounded-full transition-all duration-300 hover:scale-110 active:scale-95 shadow-lg shadow-pink-500/50"
                >
                  {isPlaying ? 
                    <Pause size={24} className="transition-transform duration-300" /> : 
                    <Play size={24} className="transition-transform duration-300 translate-x-0.5" />
                  }
                </button>
                <button 
                  onClick={nextSong} 
                  className="text-pink-300 hover:text-white transition-all duration-300 hover:scale-110 active:scale-95 p-2 rounded-full hover:bg-white/10"
                >
                  <SkipForward size={20} />
                </button>
              </div>

              <div className="w-12"></div> {/* Empty space for balance */}
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes slide-in {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes bounce-in {
          0% {
            opacity: 0;
            transform: translateX(-50%) translateY(-10px) scale(0.8);
          }
          50% {
            transform: translateX(-50%) translateY(-5px) scale(1.05);
          }
          100% {
            opacity: 1;
            transform: translateX(-50%) translateY(0) scale(1);
          }
        }

        .animate-slide-in {
          animation: slide-in 0.5s ease-out;
        }

        .animate-bounce-in {
          animation: bounce-in 0.6s ease-out;
        }

        .slider {
          background: transparent;
        }

        .slider::-webkit-slider-track {
          background: transparent;
        }

        .slider::-webkit-slider-thumb {
          appearance: none;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #ec4899, #f43f5e);
          cursor: pointer;
          box-shadow: 0 0 15px rgba(236, 72, 153, 0.8);
          opacity: 0;
          transition: all 0.3s ease;
          transform: scale(0);
        }

        .slider:hover::-webkit-slider-thumb,
        .slider:active::-webkit-slider-thumb {
          opacity: 1;
          transform: scale(1.2);
        }

        .slider::-moz-range-track {
          background: transparent;
          border: none;
        }

        .slider::-moz-range-thumb {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #ec4899, #f43f5e);
          cursor: pointer;
          border: none;
          box-shadow: 0 0 15px rgba(236, 72, 153, 0.8);
          opacity: 0;
          transform: scale(0);
          transition: all 0.3s ease;
        }

        .slider:hover::-moz-range-thumb,
        .slider:active::-moz-range-thumb {
          opacity: 1;
          transform: scale(1.2);
        }

        .volume-slider::-webkit-slider-thumb {
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: linear-gradient(45deg, #ec4899, #f43f5e);
          cursor: pointer;
          box-shadow: 0 0 10px rgba(236, 72, 153, 0.5);
          transition: all 0.3s ease;
        }

        .volume-slider::-webkit-slider-thumb:hover {
          transform: scale(1.2);
          box-shadow: 0 0 15px rgba(236, 72, 153, 0.8);
        }

        .volume-slider::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: linear-gradient(45deg, #ec4899, #f43f5e);
          cursor: pointer;
          border: none;
          box-shadow: 0 0 10px rgba(236, 72, 153, 0.5);
        }
      `}</style>
      <audio
  ref={audioRef}
  src={nowPlaying ? `/songs/${nowPlaying}.mp3` : null}
  preload="auto"
/>
    </div>
  );
}